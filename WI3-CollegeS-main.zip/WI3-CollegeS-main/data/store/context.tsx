import { createContext } from "react";

const RootContext = createContext(null);

export default RootContext;